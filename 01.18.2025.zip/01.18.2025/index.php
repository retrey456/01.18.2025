<?php
include 'Book.php';
include 'Reader.php';
include 'Library.php';

$library = new Library();
$library->addBook(new Book("Книга 1", "Автор 1", 2025));
$library->addBook(new Book("Книга 2", "Автор 2", 2024));

$reader = new Reader("qwerty123", "qwerty123321@gmail.com");
$reader->borrowBook($library->books[0]);

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>
    <h1>Список книг в библиотеке</h1>
    
    <div class="book-list">
        <?php $library->listBooks(); ?>
    </div>
</body>
</html>
